//server/config/officeLocation.js
module.exports = {
    latitude: 12.94198577,      
    longitude: 80.21012198,
    radiusMeters: 200,      // Acceptable distance from office (200m)
  };